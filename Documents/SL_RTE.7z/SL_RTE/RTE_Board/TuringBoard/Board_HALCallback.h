#ifndef __BOARD_HALCALLBACK_H
#define __BOARD_HALCALLBACK_H
#include "stm32h7xx_hal.h"
#include "Board_Config.h"
#include "RTE_Include.h"

#endif

#ifndef __BSP_SYSTICK_H
#define __BSP_SYSTICK_H
#include "stm32h7xx_hal.h"
#include "Board_Config.h"
#include "RTE_Include.h"
extern void BSP_Systick_Init(void);
#endif
